package com.example.abdulrhman.quizapp;


import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    int score = 0;
    int fault = 0;

    private RadioGroup radioGroupJourney;
    private RadioGroup radioGroupTechnical;

    private CheckBox chkBxNile;
    private CheckBox chkBxEgyptRiver;
    private CheckBox chkBxNepal;
    private CheckBox chkBxAfrica;
    private CheckBox chkBxEurope;
    private CheckBox chkBxMiddleEast;
    private CheckBox chkBxLearning;
    private CheckBox chkBxEnjoying;
    private CheckBox chkBxPlayFootball;
   private EditText ques1 ;
    private  EditText ques2;


  private CompoundButton.OnCheckedChangeListener chkCheckedListner;
    //Interface definition for a callback to be invoked when the checked state of a compound button changed.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupUI();
    }

    public void setupUI() {
        chkBxNile = (CheckBox) findViewById(R.id.nile);
        chkBxEgyptRiver = (CheckBox) findViewById(R.id.egyptriver);
        chkBxNepal = (CheckBox) findViewById(R.id.nepal);

        chkBxAfrica = (CheckBox) findViewById(R.id.africa);
        chkBxEurope = (CheckBox) findViewById(R.id.europe);
        chkBxMiddleEast = (CheckBox) findViewById(R.id.middleeast);

        chkBxLearning = (CheckBox) findViewById(R.id.learning);
        chkBxEnjoying = (CheckBox) findViewById(R.id.enjoying);
        chkBxPlayFootball = (CheckBox) findViewById(R.id.playingfootball);

        radioGroupJourney = (RadioGroup) findViewById(R.id.journey);
        radioGroupTechnical = (RadioGroup) findViewById(R.id.technical);

        setListeners();
    }


    public void setListeners() {

        chkCheckedListner = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton selectedcBox, boolean isChecked) {
                // Check which checkbox was clicked


                switch (selectedcBox.getId()) {
                    case R.id.nile:
                        if (isChecked) {
                            score += 1;
                        }
                        break;
                    case R.id.egyptriver:
                        if (isChecked) {
                            score += 1;
                        }
                        break;
                    case R.id.nepal:
                        if (isChecked) {
                            fault += 1;
                        }
                        break;


                    case R.id.africa:
                        if (isChecked) {
                            score += 1;
                        }
                        break;
                    case R.id.europe:
                        if (isChecked) {
                            fault += 1;
                        }
                        break;
                    case R.id.middleeast:
                        if (isChecked) {
                            score += 1;
                        }
                        break;


                    case R.id.learning:
                        if (isChecked) {
                            score += 1;
                        }
                        break;

                    case R.id.enjoying:
                        if (isChecked) {
                            score += 1;
                        }
                        break;
                    case R.id.playingfootball:
                        if (isChecked) {
                            fault += 1;
                        }
                        break;
                }
            }
        };

        chkBxNile.setOnCheckedChangeListener(chkCheckedListner);
        //what does this line exactly do ?
        //this set the chkBxNile to listen to the event of changing values of checked
        chkBxEgyptRiver.setOnCheckedChangeListener(chkCheckedListner);
        chkBxNepal.setOnCheckedChangeListener(chkCheckedListner);

        chkBxAfrica.setOnCheckedChangeListener(chkCheckedListner);
        chkBxEurope.setOnCheckedChangeListener(chkCheckedListner);
        chkBxMiddleEast.setOnCheckedChangeListener(chkCheckedListner);

        chkBxLearning.setOnCheckedChangeListener(chkCheckedListner);
        chkBxEnjoying.setOnCheckedChangeListener(chkCheckedListner);
        chkBxPlayFootball.setOnCheckedChangeListener(chkCheckedListner);

        // is this is a creating of interface
        RadioGroup.OnCheckedChangeListener radioCheckChangeListener = new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int radioButtonId) {
                switch (radioGroup.getId()) {
                    case R.id.journey:
                        if (R.id.radio_yes == radioButtonId) {
                            score += 1;
                        }

                        if (R.id.radio_no == radioButtonId) {
                            fault += 1;
                        }
                        break;
                    case R.id.technical:
                        if (R.id.radio_yes2 == radioButtonId) {
                            score += 1;
                        }

                        if (R.id.radio_no2 == radioButtonId) {
                            fault += 1;
                        }
                        break;
                }
            }
        };

        radioGroupTechnical.setOnCheckedChangeListener(radioCheckChangeListener);
        radioGroupJourney.setOnCheckedChangeListener  (radioCheckChangeListener);

        // creat listeners for the EditTexts

         ques1 = (EditText) findViewById(R.id.ques1);
        ques2 = (EditText)findViewById(R.id.ques2);


 if( ques1.getText().toString().trim().equals("Ankara")){
     score+=1;
 } else{

     fault+=1;
//     Toast toast =  Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT);
//     toast.show();
//     toast.setText("you have an incorrect answer");
//     toast.setGravity(Gravity.BOTTOM ,0, 100);
 }

 if (ques2.getText().toString().trim().equals("1939")){
     score+=1;
 }
else {
     fault+=1;
//     Toast toast =  Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT);
//     toast.show();
//     toast.setText("you have an incorrect answer");
//     toast.setGravity(Gravity.BOTTOM ,0, 100);
 }
    };



    public void display(String message) {

        TextView ScoreView = (TextView) findViewById(R.id.socre_view);
        ScoreView.setText(message);
        ScoreView.setHighlightColor(Color.YELLOW);
    }

    public void submit(View view) {
        display("the score is" + score + "\n the fualts is " + fault);

        Toast toast =  Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT);
        toast.show();
        toast.setText("the score is" + score + "\n the fualts is " + fault);
        toast.setGravity(Gravity.BOTTOM ,0, 100);

    }


    public void reset(View view) {
        // ToDo: You might want to rest the view too
        radioGroupJourney.clearCheck();
        radioGroupTechnical.clearCheck();

        //reset all check boxs
        chkBxNile.setChecked(false);
        chkBxEgyptRiver.setChecked(false);
        chkBxAfrica.setChecked(false);
        chkBxEnjoying.setChecked(false);
        chkBxEurope.setChecked(false);
        chkBxMiddleEast.setChecked(false);
        chkBxNepal.setChecked(false);
        chkBxLearning.setChecked(false);
        chkBxPlayFootball.setChecked(false);
        ques1.setText("");
        ques2.setText("");

        score = 0;
        fault = 0;

        display("the score is" + score + "\n the fualts is " + fault);
    }
}
